import React from "react";

export default function MyLife() {
  return (
    <div className="min-h-screen bg-white text-gray-800">
      <header className="bg-gray-100 p-6 shadow-md">
        <h1 className="text-4xl font-bold">MyLife</h1>
        <p className="text-lg text-gray-600">Sveiki atvykę į mano portfolio!</p>
      </header>

      <main className="p-6 grid gap-10">
        {/* Apie Mane */}
        <section id="about" className="max-w-3xl mx-auto">
          <h2 className="text-2xl font-semibold mb-4">Apie mane</h2>
          <p>
            Aš esu kūrybingas žmogus, mėgstantis fotografuoti, kurti ir dalyvauti įvairiuose renginiuose. Ši svetainė – mano darbų ir patirčių atspindys.
          </p>
        </section>

        {/* Portfolio */}
        <section id="portfolio" className="max-w-5xl mx-auto">
          <h2 className="text-2xl font-semibold mb-4">Nuotraukų portfolio</h2>
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
            {[...Array(6)].map((_, i) => (
              <div key={i} className="rounded-2xl overflow-hidden shadow bg-gray-200 aspect-square flex items-center justify-center">
                <span className="text-gray-400 text-xl">Nuotrauka {i + 1}</span>
              </div>
            ))}
          </div>
        </section>

        {/* Renginiai */}
        <section id="events" className="max-w-3xl mx-auto">
          <h2 className="text-2xl font-semibold mb-4">Renginiai</h2>
          <ul className="space-y-4">
            <li className="border-l-4 border-blue-500 pl-4">
              <h3 className="font-bold">2025-06-10: Vasaros paroda</h3>
              <p>Paroda, kurioje eksponavau savo fotografijas.</p>
            </li>
            <li className="border-l-4 border-blue-500 pl-4">
              <h3 className="font-bold">2025-04-22: Kūrybos vakaras</h3>
              <p>Renginys su meniniais pasirodymais ir kūrybinėmis dirbtuvėmis.</p>
            </li>
          </ul>
        </section>

        {/* Kontaktai */}
        <section id="contact" className="max-w-3xl mx-auto">
          <h2 className="text-2xl font-semibold mb-4">Kontaktai</h2>
          <p>El. paštas: <a href="mailto:example@email.com" className="text-blue-600 underline">example@email.com</a></p>
        </section>
      </main>

      <footer className="bg-gray-100 mt-10 p-4 text-center text-sm text-gray-500">
        &copy; 2025 MyLife
      </footer>
    </div>
  );
}
